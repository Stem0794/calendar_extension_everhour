// Storage helpers
const storage = {
  get: (keys) => new Promise((res) => chrome.storage.local.get(keys, res)),
  set: (obj) => new Promise((res) => chrome.storage.local.set(obj, res)),
  remove: (key) => new Promise((res) => chrome.storage.local.remove(key, res))
};

let groupMetaMap = {};

function refreshGroupOptions(projects) {
  const datalist = document.getElementById('group-options');
  if (!datalist) return;
  datalist.innerHTML = '';
  groupMetaMap = {};
  const seen = new Set();
  projects.forEach((p) => {
    const name = (p.group || '').trim();
    if (!name) return;
    const key = name.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    groupMetaMap[key] = { name, color: p.color || '#42a5f5' };
    const opt = document.createElement('option');
    opt.value = name;
    datalist.appendChild(opt);
  });
}

function applyGroupColorSelection(groupName) {
  const key = (groupName || '').trim().toLowerCase();
  const match = groupMetaMap[key];
  if (match) {
    const colorInput = document.getElementById('new-project-color');
    if (colorInput) colorInput.value = match.color || '#42a5f5';
  }
}

const newProjectGroupInput = document.getElementById('new-project-group');
if (newProjectGroupInput) {
  ['input', 'change'].forEach((evt) => {
    newProjectGroupInput.addEventListener(evt, (e) => applyGroupColorSelection(e.target.value));
  });
}

// --- TABS ---
document.querySelectorAll('.tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((t) => t.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach((c) => c.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById(tab.dataset.tab).classList.add('active');
  });
});

async function addLog(message) {
  const { logs = [] } = await storage.get('logs');
  logs.push({ msg: message, date: new Date().toLocaleString() });
  await storage.set({ logs });
}

async function loadLogs() {
  const { logs = [] } = await storage.get('logs');
  const list = document.getElementById('log-list');
  if (!list) return;
  list.innerHTML = '';
  logs
    .slice()
    .reverse()
    .forEach((l) => {
      const li = document.createElement('li');
      li.textContent = `[${l.date}] ${l.msg}`;
      list.appendChild(li);
    });
}

// Load and save Everhour token
async function loadEverhourToken() {
  const { everhourToken = '' } = await storage.get('everhourToken');
  document.getElementById('everhour-token').value = everhourToken;
}

async function saveEverhourToken() {
  const token = document.getElementById('everhour-token').value.trim();
  await storage.set({ everhourToken: token });
  await addLog('Everhour token updated');
  const status = document.getElementById('token-status');
  status.textContent = 'Saved!';
  setTimeout(() => {
    status.textContent = '';
  }, 1500);
  loadLogs();
}

document.getElementById('save-token').onclick = saveEverhourToken;

// Project list rendering and CRUD
async function renderProjectList() {
  const { projects = [] } = await storage.get('projects');
  refreshGroupOptions(projects);
  const list = document.getElementById('project-list');
  list.innerHTML = '';
  const groupBounds = {};
  projects.forEach((p, i) => {
    const g = p.group || '';
    if (!groupBounds[g]) groupBounds[g] = { first: i, last: i };
    else groupBounds[g].last = i;
  });
  let lastGroup = null;
  projects.forEach((proj, idx) => {
    if (proj.group !== lastGroup) {
      const gh = document.createElement('li');
      gh.textContent = proj.group || 'Ungrouped';
      gh.className = 'group-header';
      list.appendChild(gh);
      lastGroup = proj.group;
    }
    const li = document.createElement('li');
    li.classList.add('project-item');
    li.dataset.idx = idx;
    li.draggable = !proj._edit;
    li.style.alignItems = 'center';
    const dot = document.createElement('span');
    dot.className = 'color-dot';
    dot.style.background = proj.color || '#c1d6f9';
    li.appendChild(dot);
    const bounds = groupBounds[proj.group || ''];
    const showUp = idx > bounds.first;
    const showDown = idx < bounds.last;
    if (proj._edit) {
      const nameInput = document.createElement('input');
      nameInput.type = 'text';
      nameInput.className = 'rename-input';
      nameInput.value = proj.name;
      nameInput.id = `rename-proj-${idx}`;

      const colorInput = document.createElement('input');
      colorInput.type = 'color';
      colorInput.id = `edit-color-${idx}`;
      colorInput.value = proj.color || '#42a5f5';
      colorInput.style.marginLeft = '6px';
      colorInput.style.width = '32px';

      const keywordInput = document.createElement('input');
      keywordInput.type = 'text';
      keywordInput.className = 'keyword-input';
      keywordInput.value = (proj.keywords || []).join(', ');
      keywordInput.id = `edit-keywords-${idx}`;
      keywordInput.placeholder = 'Keywords';

      const taskInput = document.createElement('input');
      taskInput.type = 'text';
      taskInput.className = 'task-input';
      taskInput.value = proj.taskId || '';
      taskInput.id = `edit-task-${idx}`;
      taskInput.placeholder = 'Task ID';

      const groupInput = document.createElement('input');
      groupInput.type = 'text';
      groupInput.className = 'group-input';
      groupInput.value = proj.group || '';
      groupInput.id = `edit-group-${idx}`;
      groupInput.placeholder = 'Group';

      const saveBtn = document.createElement('button');
      saveBtn.className = 'save-btn';
      saveBtn.dataset.idx = idx;
      saveBtn.textContent = 'Save';

      const cancelBtn = document.createElement('button');
      cancelBtn.className = 'cancel-btn';
      cancelBtn.dataset.idx = idx;
      cancelBtn.textContent = 'Cancel';

      const searchTaskBtn = document.createElement('button');
      searchTaskBtn.type = 'button';
      searchTaskBtn.title = 'Search Everhour tasks';
      searchTaskBtn.textContent = '🔍';
      searchTaskBtn.style.cssText = 'padding:4px 8px;font-size:13px;';
      searchTaskBtn.onclick = () => openTaskSearch(`edit-task-${idx}`);

      li.appendChild(nameInput);
      li.appendChild(colorInput);
      li.appendChild(keywordInput);
      li.appendChild(taskInput);
      li.appendChild(searchTaskBtn);
      li.appendChild(groupInput);
      li.appendChild(saveBtn);
      li.appendChild(cancelBtn);
    } else {
      const kw = (proj.keywords || []).join(', ');
      const nameSpan = document.createElement('span');
      nameSpan.textContent = proj.name;
      li.appendChild(nameSpan);
      if (kw) {
        const kwSpan = document.createElement('span');
        kwSpan.style.marginLeft = '7px';
        kwSpan.style.fontSize = '11px';
        kwSpan.style.color = '#8c98ac';
        kwSpan.textContent = `[${kw}]`;
        li.appendChild(kwSpan);
      }
      const editBtn = document.createElement('button');
      editBtn.className = 'edit-btn';
      editBtn.dataset.idx = idx;
      editBtn.textContent = 'Edit';

      const deleteBtn = document.createElement('button');
      deleteBtn.className = 'delete-btn';
      deleteBtn.dataset.idx = idx;
      deleteBtn.title = 'Delete';
      deleteBtn.textContent = 'Delete';

      li.appendChild(editBtn);
      li.appendChild(deleteBtn);

      if (showUp) {
        const upBtn = document.createElement('button');
        upBtn.className = 'move-btn up';
        upBtn.dataset.idx = idx;
        upBtn.title = 'Move up';
        upBtn.textContent = '↑';
        li.appendChild(upBtn);
      }
      if (showDown) {
        const downBtn = document.createElement('button');
        downBtn.className = 'move-btn down';
        downBtn.dataset.idx = idx;
        downBtn.title = 'Move down';
        downBtn.textContent = '↓';
        li.appendChild(downBtn);
      }
    }
    list.appendChild(li);
  });
  // Edit project
  list.querySelectorAll('.edit-btn').forEach((btn) => {
    btn.onclick = async () => {
      const { projects = [] } = await storage.get('projects');
      projects[+btn.dataset.idx]._edit = true;
      await storage.set({ projects });
      renderProjectList();
    };
  });
  // Cancel edit
  list.querySelectorAll('.cancel-btn').forEach((btn) => {
    btn.onclick = async () => {
      const { projects = [] } = await storage.get('projects');
      projects[+btn.dataset.idx]._edit = false;
      await storage.set({ projects });
      renderProjectList();
    };
  });
  // Save edits
  list.querySelectorAll('.save-btn').forEach((btn) => {
    btn.onclick = async () => {
      const idx = +btn.dataset.idx;
      const name = document.getElementById(`rename-proj-${idx}`).value.trim();
      const color = document.getElementById(`edit-color-${idx}`).value;
      const keywords = document
        .getElementById(`edit-keywords-${idx}`)
        .value.split(',')
        .map((k) => k.trim())
        .filter(Boolean);
      const taskId = document.getElementById(`edit-task-${idx}`).value.trim();
      const group = document.getElementById(`edit-group-${idx}`).value.trim();
      let { projects = [] } = await storage.get('projects');
      if (!name) {
        alert('Project name cannot be empty');
        return;
      }
      const nameLower = name.toLowerCase();
      if (projects.some((p, i) => i !== idx && p.name.toLowerCase() === nameLower)) {
        alert('A project with this name already exists');
        return;
      }
      const oldName = projects[idx].name;
      projects[idx] = { name, color, keywords, taskId, group, _edit: false };
      await storage.set({ projects });
      let { meetingProjectMap = {} } = await storage.get('meetingProjectMap');
      if (name !== oldName) {
        Object.keys(meetingProjectMap).forEach((t) => {
          if (meetingProjectMap[t] === oldName) meetingProjectMap[t] = name;
        });
        await storage.set({ meetingProjectMap });
      }
      renderProjectList();
    };
  });
  // Delete project
  list.querySelectorAll('.delete-btn').forEach((btn) => {
    btn.onclick = async () => {
      let { projects = [] } = await storage.get('projects');
      const toDelete = projects[+btn.dataset.idx].name;
      projects.splice(+btn.dataset.idx, 1);
      await storage.set({ projects });
      let { meetingProjectMap = {} } = await storage.get('meetingProjectMap');
      Object.keys(meetingProjectMap).forEach((t) => {
        if (meetingProjectMap[t] === toDelete) delete meetingProjectMap[t];
      });
      await storage.set({ meetingProjectMap });
      renderProjectList();
    };
  });
  // Move project
  function move(idx, dir) {
    storage.get('projects').then(({ projects = [] }) => {
      const ni = idx + dir;
      if (ni < 0 || ni >= projects.length) return;
      const [p] = projects.splice(idx, 1);
      projects.splice(ni, 0, p);
      storage.set({ projects }).then(renderProjectList);
    });
  }
  list.querySelectorAll('.move-btn.up').forEach((btn) => {
    btn.onclick = () => move(+btn.dataset.idx, -1);
  });
  list.querySelectorAll('.move-btn.down').forEach((btn) => {
    btn.onclick = () => move(+btn.dataset.idx, 1);
  });

  // Drag & drop reorder
  let dragIdx = null;
  list.querySelectorAll('.project-item').forEach((item) => {
    item.addEventListener('dragstart', (e) => {
      dragIdx = +item.dataset.idx;
      e.dataTransfer.effectAllowed = 'move';
      item.classList.add('dragging');
    });
    item.addEventListener('dragend', () => {
      dragIdx = null;
      item.classList.remove('dragging');
      list.querySelectorAll('.drag-over').forEach((el) => el.classList.remove('drag-over'));
    });
    item.addEventListener('dragover', (e) => {
      if (dragIdx === null) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      list.querySelectorAll('.drag-over').forEach((el) => el.classList.remove('drag-over'));
      item.classList.add('drag-over');
    });
    item.addEventListener('dragleave', () => item.classList.remove('drag-over'));
    item.addEventListener('drop', async (e) => {
      if (dragIdx === null) return;
      e.preventDefault();
      const targetIdx = +item.dataset.idx;
      item.classList.remove('drag-over');
      if (dragIdx === targetIdx) return;
      let { projects = [] } = await storage.get('projects');
      const [moved] = projects.splice(dragIdx, 1);
      const insertIdx = dragIdx < targetIdx ? targetIdx - 1 : targetIdx;
      projects.splice(insertIdx, 0, moved);
      await storage.set({ projects });
      renderProjectList();
    });
  });
}

// Everhour task search
let taskSearchTargetInput = null;

async function openTaskSearch(targetInputId) {
  const { everhourToken = '' } = await storage.get('everhourToken');
  if (!everhourToken) {
    alert('Please save your Everhour API token in the Everhour tab first.');
    return;
  }
  taskSearchTargetInput = targetInputId;
  const overlay = document.getElementById('task-search-overlay');
  const input = document.getElementById('task-search-input');
  const results = document.getElementById('task-search-results');
  input.value = '';
  results.innerHTML = '<span style="color:#888;">Enter a task name and click Search.</span>';
  overlay.style.display = 'block';
  input.focus();
}

async function runTaskSearch() {
  const { everhourToken = '' } = await storage.get('everhourToken');
  const query = document.getElementById('task-search-input').value.trim();
  const results = document.getElementById('task-search-results');
  if (!query) return;
  results.innerHTML = '<span style="color:#888;">Fetching projects…</span>';

  try {
    // Fetch ALL projects (paginate if needed)
    let allProjects = [];
    let page = 1;
    while (true) {
      const projRes = await fetch(`https://api.everhour.com/projects?limit=100&page=${page}`, {
        headers: { 'X-Api-Key': everhourToken }
      });
      if (!projRes.ok) throw new Error(`Projects fetch failed (${projRes.status})`);
      const batch = await projRes.json();
      if (!Array.isArray(batch) || !batch.length) break;
      allProjects = allProjects.concat(batch);
      if (batch.length < 100) break;
      page++;
    }

    results.innerHTML = `<span style="color:#888;">Searching tasks across ${allProjects.length} projects…</span>`;

    const queryLower = query.toLowerCase();

    // Batch project-task fetches to avoid hammering the API (5 at a time)
    const matches = [];
    for (let i = 0; i < allProjects.length; i += 20) {
      const batch = allProjects.slice(i, i + 20);
      const batchResults = await Promise.all(
        batch.map(async (proj) => {
          try {
            const tRes = await fetch(
              `https://api.everhour.com/projects/${encodeURIComponent(proj.id)}/tasks?limit=500`,
              {
                headers: { 'X-Api-Key': everhourToken }
              }
            );
            if (!tRes.ok) return [];
            const tasks = await tRes.json();
            return (Array.isArray(tasks) ? tasks : [])
              .filter((t) => t.name && t.name.toLowerCase().includes(queryLower))
              .map((t) => ({
                ...t,
                // Preserve the full task ID including any integration prefix (li:, gh:, etc.)
                id: t.id,
                projectName: proj.name,
                projectId: proj.id
              }));
          } catch {
            return [];
          }
        })
      );
      matches.push(...batchResults.flat());
    }

    if (!matches.length) {
      results.innerHTML = `<span style="color:#888;">No matching tasks found across ${allProjects.length} projects.</span>`;
      return;
    }

    results.innerHTML = '';
    matches.forEach((task) => {
      const row = document.createElement('div');
      row.style.cssText =
        'padding:7px 8px;cursor:pointer;border-radius:4px;border-bottom:1px solid var(--border-light);';
      row.innerHTML = `<span style="font-weight:500;">${escapeHtml(task.name)}</span><br><span style="font-size:11px;color:#888;">${escapeHtml(task.projectName)} · ID: <code>${escapeHtml(String(task.id))}</code></span>`;
      row.onmouseenter = () => (row.style.background = 'var(--bg-hover, #f0f4ff)');
      row.onmouseleave = () => (row.style.background = '');
      row.onclick = () => {
        if (taskSearchTargetInput) {
          const el = document.getElementById(taskSearchTargetInput);
          if (el) el.value = task.id;
        }
        closeTaskSearch();
      };
      results.appendChild(row);
    });
  } catch (e) {
    results.innerHTML = `<span style="color:#c00;">Error: ${escapeHtml(e.message)}</span>`;
  }
}
function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function closeTaskSearch() {
  const overlay = document.getElementById('task-search-overlay');
  if (overlay) overlay.style.display = 'none';
}

const searchTaskNewBtn = document.getElementById('search-task-new');
if (searchTaskNewBtn) searchTaskNewBtn.onclick = () => openTaskSearch('new-project-task');

const taskSearchCloseBtn = document.getElementById('task-search-close');
if (taskSearchCloseBtn) taskSearchCloseBtn.onclick = closeTaskSearch;

const taskSearchGoBtn = document.getElementById('task-search-go');
if (taskSearchGoBtn) taskSearchGoBtn.onclick = runTaskSearch;

const taskSearchInput = document.getElementById('task-search-input');
if (taskSearchInput)
  taskSearchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') runTaskSearch();
  });

const taskSearchOverlay = document.getElementById('task-search-overlay');
if (taskSearchOverlay)
  taskSearchOverlay.addEventListener('click', (e) => {
    if (e.target === taskSearchOverlay) closeTaskSearch();
  });

// Add new project
document.getElementById('add-project').onclick = async () => {
  const inp = document.getElementById('new-project');
  const color = document.getElementById('new-project-color').value || '#42a5f5';
  const kwds = document
    .getElementById('new-project-keywords')
    .value.split(',')
    .map((k) => k.trim())
    .filter(Boolean);
  const taskId = document.getElementById('new-project-task').value.trim();
  const group = document.getElementById('new-project-group').value.trim();
  const name = inp.value.trim();
  if (!name) return;
  let { projects = [] } = await storage.get('projects');
  if (!projects.find((p) => p.name === name)) {
    const newProject = { name, color, keywords: kwds, taskId, group };
    const normalizedGroup = group || '';
    const lastInGroup = [...projects]
      .map((p, i) => ({ g: p.group || '', i }))
      .filter((p) => p.g === normalizedGroup)
      .map((p) => p.i)
      .pop();
    if (lastInGroup === undefined) {
      projects.push(newProject);
    } else {
      projects.splice(lastInGroup + 1, 0, newProject);
    }
    await storage.set({ projects });
    renderProjectList();
  }
  inp.value = '';
  document.getElementById('new-project-keywords').value = '';
  document.getElementById('new-project-task').value = '';
  document.getElementById('new-project-group').value = '';
};

// Export settings without API token
async function exportSettings() {
  const data = await storage.get(null);
  delete data.everhourToken;
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.getElementById('download-link');
  link.href = url;
  link.download = 'settings_export.json';
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  addLog('Exported settings');
}
document.getElementById('export-settings').onclick = exportSettings;

// Import settings from file and merge into storage, excluding API token
async function importSettings() {
  const fileInput = document.getElementById('import-file');
  const file = fileInput.files[0];
  if (!file) return;
  let text = '';
  try {
    text = await file.text();
  } catch (e) {
    alert('Could not read file');
    return;
  }
  let data;
  try {
    data = JSON.parse(text);
  } catch (e) {
    alert('Invalid JSON');
    return;
  }
  delete data.everhourToken;
  const current = await storage.get(null);
  await storage.set({ ...current, ...data });
  await addLog('Imported settings');
  renderProjectList();
  fileInput.value = '';
}
document.getElementById('import-settings').onclick = importSettings;

// --- Dark Mode ---
function updateDarkModeUI(isDark) {
  const btn = document.getElementById('dark-mode-toggle');
  const label = document.getElementById('dark-mode-label');
  if (btn) btn.textContent = isDark ? '☀️' : '🌙';
  if (label) label.textContent = isDark ? 'Dark mode' : 'Light mode';
}

async function initDarkMode() {
  const { darkMode = false } = await storage.get('darkMode');
  if (darkMode) document.body.classList.add('dark');
  updateDarkModeUI(darkMode);
}

document.getElementById('dark-mode-toggle').onclick = async () => {
  const isDark = document.body.classList.toggle('dark');
  await storage.set({ darkMode: isDark });
  updateDarkModeUI(isDark);
  await addLog(isDark ? 'Dark mode enabled' : 'Dark mode disabled');
};

// Init
initDarkMode();
loadEverhourToken();
renderProjectList();
loadLogs();
chrome.storage.onChanged.addListener((changes) => {
  if (changes.logs) loadLogs();
});
